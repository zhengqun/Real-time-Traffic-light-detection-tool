# final_software for Traffic light detection.

Dependencies:

cv2
numpy
sklearn(0.20.2)
skimage(0.14.2)
matplotlib
yaml
os
tflearn
tensorflow
pickle
time

Sample usage:
Layer upto SVM:
	Train A Model
		Customize settings in config.yaml (see config options for more information)
		Run train.py
	Run A Model
		Customize settings in config.yaml (see config options for more information)
		Run run.py
	
Including the CNN Classifier:
	Train A Model
		Customize settings in config.yaml (see config options for more information)
		Run train.py
		Run cnn/cnn_train.py
	Run A Model
		Customize settings in config.yaml (see config options for more information)
		Run final_run.py

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Data Flow:

Input image(Any resolution)/video[1]-->
top n%[2] of the image is extracted-->
HSV color segmentation/Spot light detection of the top half followed by watershed algorithm to possible candidate regions-->
HOG+SVM(descriptor+ML based TL detection)classifying these candidate regions into TL or background. validate for possible TL objects for a given window size and outputs the possible ROIs which may still contain false positives-->
Final classification of these proposals by a CNN classifier into 3 classes:Red,Green and Background-->
Final detection with state of the TL objects with the state colored boundary boxes on Green and Red TLs


[1]To input a video,Please(modify the final_run.py/svm_run.py) in video() function with video path, and output video configurations like fps, frame size etc.Also call this function instead of main() in line 152 of final_run.py
This chain was originally meant to take images as inputs but later extend to video inputs,hence the video configurations are not mentioned in the config.yaml file.
[2] To change the n depending your dataset's TL locations please modify  the value in the function call of cutoff_lower() in the run() functions.
 
*********************************************************************************************************************************************************************************

The final software can be run in multiple modes:

1.With base detector as HSV_segmentaion or Spotlight detector,HSV_segmnataion was found to be faster,hence this configuration has been given in config file.
Similar config can be created with spotlight detector.

2.Base descriptor available is only HOG followed by SVM. Haar based classifier was attempted followed by an SVM(Has a different training pattern which is attached separately),
but HOG was found to be effective in detection.Hence only HOG settings can be found in the config file

3.The tool chain can end at step 2 by using svm_train.py and svm_run.py and the result will only contain detected TL objects without class labels

4.By using final_run.py you can include the classification by CNN also to be stacked on the SVM provided you have the stored model (checkpoints,weights) inside the cnn-directory.
For this the CNN needs to be trained before hand using the cnn_train.py and input data as mentioned below.
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Training the CNN Classifier:

1.Prepare the train and test images:
The images need to be small crops of TL objects. small images ideally 32*64 which contains the TL bulb with the box(may be partial).Name each class lights with Class*******.jpg .Egs: Green_****.jpg 
and background with Background******.jpg.I have 3 classes Red,Green and Background. Split the DS to train and test in the ratio 80:20 to form train and test folder.
Update this path and learning rates,number of epochs and other training parameters etc in the cnn_train.py
Run the cnn_train.py  to obtain the model

config.yaml file is used to train and run the the chain without the CNN layer.i.e the config file can be used to train and run the chain when used SVM is used as the last layer.
final_run.py combines both all the layers upto the CNN incuding the SVM and other layers.
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Configuration details to train upto HOG+SVM

using the sample config.yaml

train: to configure details to train descriptor(HOG)+SVM
  descriptor: only hog is available in this chain as haar features were not found to be effective as HOG
  classifier: classifier name,directs to svm.py
  outfile: location where the hog_svm model needs to be dumbed egs: hog_out.pkl
  positive_image_directory: positive image directory for training svm
  negative_image_directory: negative image directory for training svm
  window_size: required image resize

run:
  descriptor: hog
  classifier_location: location of trained SVM dumb hog_out.pkl
  detector: either hsv_segmenetation or spotlight detector
  image_directory: test input image directory path
  window_size: required image resize

svm:
  C: regularization parameter for SVM ,default value is 1

hog:            hog descriptor settings
  block_size: 
  cell_size: 
  orientations: 


colordetector_hsv:
  max_size: How large a spotlight/coloured contour can grow before being rejected
  kernel_size: dilation size
  




